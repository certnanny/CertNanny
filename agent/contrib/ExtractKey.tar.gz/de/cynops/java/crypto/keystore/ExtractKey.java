//
// Private key extraction tool
// 2005-09-21 Martin Bartosch, Cynops GmbH <m.bartosch@cynops.de>
//

/*
 Tool for Java Keystore private key extraction. 

  Usage: java de.cynops.java.crypto.keystore.ExtractKey \
	 -keystore keystore.server \
	 -storepass <keystore password> \
	 -keypass <keystore password for RSA private key> \
	 -key <key label>
	 -keyfile <output file name>

Example:
java -classpath ExtractKey.jar de.cynops.java.crypto.keystore.ExtractKey -key ibmwebspheremqqm123456 -keyfile foo.p8 -keystore key.kdb -storepass dory -keypass dory -type CMS -provider IBMJCE

Example2 (using gsk6cmd infrastructure):



Known bugs:
This Program Is Ugly.

*/

package de.cynops.java.crypto.keystore;

import java.io.*;
import java.util.*;
import java.security.*;
import java.security.cert.*;
import java.security.spec.*;
import java.lang.System.*;
import java.security.Provider;
import java.lang.reflect.Method;

public class ExtractKey {

    public static void main(String[] args) {
	try {
	    
	    String ksFilename = null;
	    String ksType = null;
	    String ksProvider = null;
	    String storePassword = null;
	    String keyFilename = null;
	    String keyLabel = null;
	    String keyPassword = null;

	    for(int ii = 0; ii < args.length; ii++) {
		
		if(args[ii].equalsIgnoreCase("-keystore")) {
		    ii++;
		    ksFilename = new String(args[ii]);
		    continue;
		}
		
		if(args[ii].equalsIgnoreCase("-type")) {
		    ii++;
		    ksType = new String(args[ii]);
		    continue;
		}

		if(args[ii].equalsIgnoreCase("-provider")) {
		    ii++;
		    ksProvider = new String(args[ii]);
		    continue;
		}
		
		if(args[ii].equalsIgnoreCase("-storepass")) {
		    ii++;
		    storePassword = new String(args[ii]);
		    continue;
		}

		if(args[ii].equalsIgnoreCase("-key")) {
		    ii++;
		    keyLabel = new String(args[ii]);
		    continue;
		}
		
		if(args[ii].equalsIgnoreCase("-keypass")) {
		    ii++;
		    keyPassword = new String(args[ii]);
		    continue;
		}

		if(args[ii].equalsIgnoreCase("-keyfile")) {
		    ii++;
		    keyFilename = new String(args[ii]);
		    continue;
		}

	    }

	    if (ksFilename == null) {
		ksFilename = new String(System.getProperty("user.home")
					+ System.getProperty("file.separator")
					+ ".keystore");
	    }

	    if (ksType == null) {
		ksType = new String("JKS");
	    }

	    if (keyLabel == null) {
		System.err.println("No key label specified.");
		System.exit(1);
	    }

	    if (keyFilename == null) {
		System.err.println("No key file specified.");
		System.exit(1);
	    }

	    
	    System.err.println("Reading keystore " + ksFilename + ".");
	    
	    if (storePassword == null)
		storePassword = "";
	    if (keyPassword == null)
		keyPassword = "";


	    FileInputStream inputstream = null;
	    inputstream = new FileInputStream(ksFilename);
	    if (inputstream == null) {
		System.err.println("Could not open keystore " + ksFilename + ".");
		System.exit(1);
	    }

	    KeyStore store = null;

	    try {
		if (ksProvider == null) {
		    store = KeyStore.getInstance(ksType);
		}
		else {
		    if (ksProvider.equals("IBMJCE")) {
			Class ks = Class.forName("com.ibm.spi.IBMKeyStore");
			Method ksGetInstance = ks.getMethod("getInstance", 
							    new Class[] { String.class });
			Object ksArgs[] = { ksType };
			store = (KeyStore)ksGetInstance.invoke(ks, ksArgs);
		    }
		    else
			store = KeyStore.getInstance(ksType, ksProvider);
		}
	    } catch (java.security.KeyStoreException ex) {
		System.err.println("Unsupported provider. Available:");

		Provider providers [] = Security.getProviders();
		
		for(int ii = 0; ii < providers.length; ii++) {
		    System.out.println(providers[ii].getInfo());
		}
		System.exit(1);
	    }

	    if (store == null) {
		System.err.println("Could not instantiate keystore.");
		System.exit(1);
	    }

	    store.load(inputstream, storePassword.toCharArray());

	    Key key = null;
	    try {
		key = store.getKey(keyLabel, keyPassword.toCharArray());
	    } catch (java.security.UnrecoverableKeyException ex) {
		System.err.println("Incorrect key pin?");
	    }

	    if (key == null) {
		System.err.println("Could not read key " + keyLabel + ".");
		System.exit(1);
	    }

	    String keyformat = new String (key.getFormat());
	    if (! (keyformat.equals("PKCS8") || keyformat.equals("PKCS#8"))) {
		System.err.println("Unsupported key format: " + key.getFormat() + ".");
		System.exit(1);
	    }

	    FileOutputStream outfile = new FileOutputStream(keyFilename);
            outfile.write(key.getEncoded());
            outfile.flush();

	} catch (Exception ex) {
	    ex.printStackTrace();
	    System.exit(1);
	}
	
    }
    
}
